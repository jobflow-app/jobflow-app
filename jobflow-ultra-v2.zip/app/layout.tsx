import "../styles/global.css";

export const metadata = {
  title: "JobFlow Ultra",
  description: "Universal field service CRM",
  icons: {
    icon: "/icon.png",
  },
};

export default function RootLayout({children}:{children:React.ReactNode}){
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}