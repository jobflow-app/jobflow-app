import Shell from "../../components/Shell";

export default function SettingsPage(){
  return (
    <Shell title="Settings / Einstellungen" subtitle="Language, company, branding and app preferences">
      <div className="twoCol">
        <div className="card">
          <h2>Company</h2>
          <div className="kv"><strong>Brand</strong><span>JobFlow</span></div>
          <div className="kv"><strong>Languages</strong><span>Deutsch / English</span></div>
          <div className="kv"><strong>Currency</strong><span>EUR</span></div>
          <div className="kv"><strong>Logo</strong><span>Your VS icon is already added</span></div>
        </div>
        <div className="card">
          <h2>Roadmap</h2>
          <div className="small">GPS tracking, PDF invoices, customer signatures, photos and notifications are prepared as next modules.</div>
        </div>
      </div>
    </Shell>
  )
}