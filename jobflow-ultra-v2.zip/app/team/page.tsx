import Shell from "../../components/Shell";

export default function TeamPage(){
  return (
    <Shell title="Team" subtitle="Workers, roles and assignments">
      <div className="card">
        <h2>Team module</h2>
        <p className="small">Owner, admin and worker roles can be added here in the next step.</p>
      </div>
    </Shell>
  )
}