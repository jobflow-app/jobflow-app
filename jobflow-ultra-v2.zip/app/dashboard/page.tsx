import Shell from "../../components/Shell";
import {metrics, jobs} from "../../lib/data";

export default function Dashboard(){
  return (
    <Shell title="Dashboard" subtitle="Good morning / Guten Morgen">
      <div className="grid">
        {metrics.map((m) => (
          <div key={m.labelEn} className={`card metric ${m.color}`}>
            <div>{m.labelEn} / {m.labelDe}</div>
            <div className="metricValue">{m.value}</div>
          </div>
        ))}
      </div>

      <div className="sectionTitle">Recent Jobs / Letzte Aufträge</div>
      <div className="list">
        {jobs.map((job) => (
          <div className="row" key={job.title}>
            <div>
              <div style={{fontSize:24,fontWeight:700}}>{job.title}</div>
              <div className="small">{job.client}</div>
            </div>
            <div style={{display:"flex",alignItems:"center",gap:12}}>
              <strong>{job.amount}</strong>
              <span className={`badge ${job.status === "done" ? "done" : job.status === "progress" ? "progress" : "new"}`}>
                {job.status}
              </span>
              <span className="small">{job.date}</span>
            </div>
          </div>
        ))}
      </div>
    </Shell>
  )
}