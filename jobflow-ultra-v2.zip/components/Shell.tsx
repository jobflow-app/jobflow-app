import Sidebar from "./Sidebar";

export default function Shell({
  title,
  subtitle,
  children,
}:{
  title:string;
  subtitle?:string;
  children:React.ReactNode;
}){
  return (
    <div className="shell">
      <Sidebar />
      <div className="content">
        <div className="topbar">
          <div>
            <h1 className="title">{title}</h1>
            {subtitle ? <p className="subtitle">{subtitle}</p> : null}
          </div>
          <img src="/logo.png" alt="JobFlow" style={{width: 84, opacity: .95}} />
        </div>
        {children}
      </div>
    </div>
  )
}