import Shell from "../../components/Shell";
import {jobs} from "../../lib/data";

export default function JobsPage(){
  return (
    <Shell title="Jobs / Aufträge" subtitle="Job operation center">
      <div className="list">
        {jobs.map((job) => (
          <div className="row" key={job.title}>
            <div>
              <div style={{fontSize:24,fontWeight:700}}>{job.title}</div>
              <div className="small">{job.client}</div>
            </div>
            <div style={{display:"flex",alignItems:"center",gap:12}}>
              <strong>{job.amount}</strong>
              <span className={`badge ${job.status === "done" ? "done" : job.status === "progress" ? "progress" : "new"}`}>
                {job.status}
              </span>
            </div>
          </div>
        ))}
      </div>
    </Shell>
  )
}