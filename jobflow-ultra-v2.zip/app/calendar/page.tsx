import Shell from "../../components/Shell";

export default function CalendarPage(){
  return (
    <Shell title="Calendar / Kalender" subtitle="Scheduling and route planning">
      <div className="card">
        <h2>GPS-ready structure</h2>
        <p className="small">
          This starter includes a place for route planning, job scheduling and future GPS integration.
        </p>
      </div>
    </Shell>
  )
}