export async function GET() {
  const sample = `%PDF-1.1
1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj
2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj
3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 300 144] /Contents 4 0 R >> endobj
4 0 obj << /Length 55 >> stream
BT /F1 18 Tf 20 100 Td (JobFlow PDF Placeholder) Tj ET
endstream endobj
xref
0 5
0000000000 65535 f 
0000000010 00000 n 
0000000060 00000 n 
0000000117 00000 n 
0000000217 00000 n 
trailer << /Root 1 0 R /Size 5 >>
startxref
322
%%EOF`;
  return new Response(sample, {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": "inline; filename=jobflow-placeholder.pdf",
    },
  });
}