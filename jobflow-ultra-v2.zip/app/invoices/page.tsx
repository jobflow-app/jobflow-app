import Shell from "../../components/Shell";
import {invoices} from "../../lib/data";

export default function InvoicesPage(){
  return (
    <Shell title="Invoices / Rechnungen" subtitle="PDF-ready invoice module">
      <div className="list">
        {invoices.map((inv) => (
          <div className="row" key={inv.no}>
            <div>
              <div style={{fontSize:22,fontWeight:700}}>{inv.no}</div>
              <div className="small">{inv.client}</div>
            </div>
            <div style={{display:"flex",alignItems:"center",gap:12}}>
              <strong>{inv.amount}</strong>
              <span className="badge new">{inv.status}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="sectionTitle">PDF Export / PDF Export</div>
      <a className="btn" href="/api/pdf">Open PDF placeholder</a>
    </Shell>
  )
}