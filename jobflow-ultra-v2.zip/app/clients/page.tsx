import Shell from "../../components/Shell";
import {clients} from "../../lib/data";

export default function ClientsPage(){
  return (
    <Shell title="Clients / Kunden" subtitle="Client CRM module">
      <div className="list">
        {clients.map((c) => (
          <div className="row" key={c.name}>
            <div>
              <div style={{fontSize:24,fontWeight:700}}>{c.name}</div>
              <div className="small">{c.phone} · {c.email}</div>
              <div className="small">{c.address}</div>
            </div>
            <strong>{c.revenue}</strong>
          </div>
        ))}
      </div>
    </Shell>
  )
}