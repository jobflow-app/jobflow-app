# JobFlow Ultra v2

Mobile-first, desktop-ready universal CRM starter for service companies.

## Included
- Your logo as `public/logo.png`
- App icon as `public/icon.png`
- Dashboard
- Clients
- Jobs
- Invoices
- Calendar
- Team
- Settings
- PDF placeholder route at `/api/pdf`

## Notes
- GPS is prepared as a future integration module, not live tracking yet.
- PDF export is included as a starter placeholder.
- This is a clean starter that you can upload to GitHub and deploy to Vercel.

## Pages
- `/`
- `/dashboard`
- `/clients`
- `/jobs`
- `/invoices`
- `/calendar`
- `/team`
- `/settings`