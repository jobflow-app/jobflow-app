export default function Home(){
  return (
    <main style={{minHeight:"100vh",display:"grid",placeItems:"center",padding:24,background:"#F5F7FB"}}>
      <div style={{maxWidth:560,textAlign:"center",background:"#fff",padding:40,borderRadius:24,boxShadow:"0 8px 30px rgba(15,42,68,.08)"}}>
        <img src="/logo.png" alt="JobFlow" style={{width:140,marginBottom:20}} />
        <h1 style={{fontSize:42,margin:"0 0 12px"}}>JobFlow Ultra</h1>
        <p style={{color:"#64748B",fontSize:18,marginBottom:24}}>
          Universal CRM for service companies. Mobile-first, desktop-ready, bilingual, PDF-ready and GPS-ready.
        </p>
        <a href="/dashboard" style={{display:"inline-block",padding:"14px 22px",borderRadius:14,background:"#2B6CB0",color:"#fff",fontWeight:700}}>
          Open Dashboard
        </a>
      </div>
    </main>
  )
}