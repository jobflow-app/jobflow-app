export const metrics = [
  { labelEn: "Today's Jobs", labelDe: "Heutige Aufträge", value: "5", color: "blue" },
  { labelEn: "Open Jobs", labelDe: "Offene Aufträge", value: "14", color: "dark" },
  { labelEn: "Completed Jobs", labelDe: "Erledigte Aufträge", value: "230", color: "green" },
  { labelEn: "Revenue Today", labelDe: "Umsatz heute", value: "€1,550", color: "orange" },
];

export const jobs = [
  { title: "Install smart lock", client: "ACME Corp", status: "done", amount: "€150", date: "Today" },
  { title: "Kitchen faucet leak", client: "John Schmidt", status: "progress", amount: "€75", date: "Today" },
  { title: "Install security camera", client: "Anne Müller", status: "new", amount: "€230", date: "April 24" },
];

export const clients = [
  { name: "ACME Corp", phone: "+49 321 123456", email: "office@acme.de", address: "Berlin", revenue: "€1500" },
  { name: "John Schmidt", phone: "+49 321 654987", email: "john@example.com", address: "Munich", revenue: "€325" },
  { name: "Marija Novak", phone: "+49 321 987654", email: "marija@example.com", address: "Salzburg", revenue: "€210" },
];

export const invoices = [
  { no: "JF-2026-001", client: "ACME Corp", amount: "€150", status: "Paid" },
  { no: "JF-2026-002", client: "John Schmidt", amount: "€75", status: "Sent" },
  { no: "JF-2026-003", client: "Marija Novak", amount: "€60", status: "Draft" },
];