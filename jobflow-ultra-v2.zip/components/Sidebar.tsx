const links = [
  ["/dashboard","Dashboard / Übersicht"],
  ["/clients","Clients / Kunden"],
  ["/jobs","Jobs / Aufträge"],
  ["/invoices","Invoices / Rechnungen"],
  ["/calendar","Calendar / Kalender"],
  ["/team","Team"],
  ["/settings","Settings / Einstellungen"],
];

export default function Sidebar(){
  return (
    <aside className="sidebar">
      <div className="brand">
        <img src="/icon.png" alt="JobFlow logo" />
        <span>JOBFLOW</span>
      </div>
      <nav className="nav">
        {links.map(([href,label]) => (
          <a key={href} href={href}>{label}</a>
        ))}
      </nav>
      <div className="small">Ultra v2 starter with logo, PDF placeholder and GPS-ready structure.</div>
    </aside>
  )
}